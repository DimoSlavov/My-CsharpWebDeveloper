﻿using static Animals.StartUp.Cat;

namespace Animals;

public class StartUp
{
    public static void Main(string[] args)
    {

        Animal cat = new Cat("Peter", "Whiskas");

        Animal dog = new Dog("George", "Meat");

        Console.WriteLine(cat.ExplainSelf());

        Console.WriteLine(dog.ExplainSelf());



    }
    


         public abstract class Animal


    { 

        private string name;
        private string favouriteFood;

        protected Animal(string name, string favoriteFood)
        {
            Name = name;
            FavoriteFood = favoriteFood;
        }

        public string Name
        {
            get=>name; set => name = value;
        }

        public string FavoriteFood
        {
            get => favouriteFood;
            set => favouriteFood = value;
        }


        public abstract string ExplainSelf();
    }
    public class Cat : Animal
    {
        public Cat(string name, string favouriteFood) : base(name, favouriteFood)
        {

        }


        public override string ExplainSelf()
        {
            return $"I am {Name} and my fovourite food is {FavoriteFood} MEEOW";
        }
        public class Dog : Animal
        {
            public Dog(string name, string favouriteFood) : base(name, favouriteFood)
            {

            }

            public override string ExplainSelf()
            {
                return $"I am {Name} and my fovourite food is {FavoriteFood} DJAAF";
            }
        }
        }
       
        
    







        
    
}