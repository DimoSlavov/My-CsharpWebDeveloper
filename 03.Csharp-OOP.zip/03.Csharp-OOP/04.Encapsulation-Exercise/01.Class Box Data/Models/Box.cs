﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassBoxData.Models
{
    public class Box
    {
        public const string PropertyValueExceptionMessage = "{0} cannot be zero or negative.";


        private double length;
        private double width;
        private double height;
        

        public Box(double length, double width, double height)
        {
            Length = length;
            Width = width;
            Height = height;
        }

        public double Length {
            get => length;
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException(string.Format(PropertyValueExceptionMessage,nameof(Length)));
                }
                this.length = value;

            }
            

            
        }
        public double Width { 
            get => width;
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException(string.Format(PropertyValueExceptionMessage, nameof(Width)));
                }
                this.width = value;

            } 
        }
        public double Height
        { 
            get => height;
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException(string.Format(PropertyValueExceptionMessage, nameof(Height)));
                }
                this.height = value;

            }
        }

        public double SurfaceArea() => (Length * Height) * 2 + (Width * Height) * 2 + (Length*Width)*2;
        public double LateralSurfaceArea() => (Length*Height)*2 + (Width*Height)*2;
        public double Volume() => Length*Width*Height;

    }
}
