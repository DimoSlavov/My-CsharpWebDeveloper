namespace Television.Tests
{
    using System;
    using NUnit.Framework;
    [TestFixture]
    public class TelevisionDeviceTests
    {
        [Test]
        public void SwitchOn_ReturnsCorrectString()
        {
           
            var television = new TelevisionDevice("TestBrand", 500.00, 1920, 1080);

            
            var result = television.SwitchOn();

            
            Assert.AreEqual("Cahnnel 0 - Volume 13 - Sound On", result);
        }

        [Test]
        public void ChangeChannel_UpdatesCurrentChannel()
        {
            
            var television = new TelevisionDevice("TestBrand", 500.00, 1920, 1080);

            
            television.ChangeChannel(5);

            
            Assert.AreEqual(5, television.CurrentChannel);
        }

        [Test]
        public void VolumeChange_IncreasesVolume()
        {
            
            var television = new TelevisionDevice("TestBrand", 500.00, 1920, 1080);

            
            var result = television.VolumeChange("UP", 10);

            
            Assert.AreEqual("Volume: 23", result);
        }

        [Test]
        public void VolumeChange_DecreasesVolume()
        {
           
            var television = new TelevisionDevice("TestBrand", 500.00, 1920, 1080);

           
            var result = television.VolumeChange("DOWN", 5);

           
            Assert.AreEqual("Volume: 8", result);
        }

        [Test]
        public void MuteDevice_TogglesMute()
        {
            
            var television = new TelevisionDevice("TestBrand", 500.00, 1920, 1080);

            
            var result1 = television.MuteDevice(); 
            var result2 = television.MuteDevice(); 

           
            Assert.IsTrue(result1);
            Assert.IsFalse(result2);
        }

        [Test]
        public void ToString_ReturnsCorrectString()
        {
            
            var television = new TelevisionDevice("TestBrand", 500.00, 1920, 1080);

            
            var result = television.ToString();

            
            Assert.AreEqual("TV Device: TestBrand, Screen Resolution: 1920x1080, Price 500$", result);
        }
    }
}