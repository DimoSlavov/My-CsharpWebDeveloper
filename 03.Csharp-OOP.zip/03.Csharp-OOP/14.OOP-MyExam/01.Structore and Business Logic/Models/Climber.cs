﻿using HighwayToPeak.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HighwayToPeak.Models
{
    public abstract class Climber : IClimber
    {
        private string name;
        private int stamina;
        private List<string> conqueredPeaks;

        public string Name
        {
            get => name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Climber's name cannot be null or whitespace.");
                name = value;
            }
        }

        public int Stamina
        {
            get => stamina;
            protected set
            {
                stamina = Math.Max(0, Math.Min(value, 10)); // Ensure stamina is between 0 and 10
            }
        }

        public IReadOnlyCollection<string> ConqueredPeaks => new ReadOnlyCollection<string>(conqueredPeaks);

        protected Climber(string name, int stamina)
        {
            Name = name;
            Stamina = stamina;
            conqueredPeaks = new List<string>();
        }

        public void Climb(IPeak peak)
        {
            if (!conqueredPeaks.Contains(peak.Name))
            {
                conqueredPeaks.Add(peak.Name);

                switch (peak.DifficultyLevel)
                {
                    case "Extreme":
                        Stamina -= 6;
                        break;
                    case "Hard":
                        Stamina -= 4;
                        break;
                    case "Moderate":
                        Stamina -= 2;
                        break;
                }
            }
        }

        public abstract void Rest(int daysCount);

        public override string ToString()
        {
            return $"{GetType().Name} - Name: {Name}, Stamina: {Stamina}\nPeaks conquered: {conqueredPeaks.Count}/{conqueredPeaks.Count}";

        }
    }
}
