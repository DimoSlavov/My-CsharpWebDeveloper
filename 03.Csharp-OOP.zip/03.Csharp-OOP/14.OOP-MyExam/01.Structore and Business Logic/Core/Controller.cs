﻿using HighwayToPeak.Core.Contracts;
using HighwayToPeak.Models;
using HighwayToPeak.Models.Contracts;
using HighwayToPeak.Repositories;
using HighwayToPeak.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HighwayToPeak.Core
{
    public class Controller : IController
    {
        private PeakRepository peaks;
        private ClimberRepository climbers;
        private BaseCamp baseCamp;

        public Controller()
        {
            peaks = new PeakRepository();
            climbers = new ClimberRepository();
            baseCamp = new BaseCamp();
        }
        public string AddPeak(string name, int elevation, string difficultyLevel)
        {
            IPeak existingPeak = peaks.Get(name);
            if(existingPeak != null)
            {
                return $"{name} is already added as a valid mountain destination.";
            } 
            if (difficultyLevel!= "Extreme"&&difficultyLevel!="Hard"&& difficultyLevel!= "Moderate")
            {
                return $"{difficultyLevel} peaks are not allowed for international climbers.";
            }
            IPeak peak = new Peak(name, elevation, difficultyLevel);
            peaks.Add(peak);
            return $"{name} is allowed for international climbing. See details in {peaks.GetType().Name}.";

            
        }

        public string AttackPeak(string climberName, string peakName)
        {
            IClimber climber = climbers.Get(climberName);
            if (climber == null)
                return $"Climber - {climberName}, has not arrived at the BaseCamp yet.";

            IPeak peak = peaks.Get(peakName);
            if (peak == null)
                return $"{peakName} is not allowed for international climbing.";

            if (!baseCamp.Residents.Contains(climberName))
                return $"{climberName} not found for gearing and instructions. The attack of {peakName} will be postponed.";

            if (peak.DifficultyLevel == "Extreme" && climber is NaturalClimber)
                return $"{climberName} does not cover the requirements for climbing {peakName}.";

            baseCamp.LeaveCamp(climberName);
            climber.Climb(peak);
            baseCamp.ArriveAtCamp(climberName);

            if (climber.Stamina <= 0)
                return $"{climberName} did not return to BaseCamp.";

            return $"{climberName} successfully conquered {peakName} and returned to BaseCamp.";
        }

        public string BaseCampReport()
        {
            if (baseCamp.Residents.Count == 0)
                return "BaseCamp is currently empty.";

            string report = "BaseCamp residents:";

            foreach (var climberName in baseCamp.Residents)
            {
                IClimber climber = climbers.Get(climberName);
                report += $"Name: {climber.Name}, Stamina: {climber.Stamina}, Count of Conquered Peaks: {climber.ConqueredPeaks.Count}\n";
            }

            return report;
        }

        public string CampRecovery(string climberName, int daysToRecover)
        {
            IClimber climber = climbers.Get(climberName);
            if (climber == null)
                return $"{climberName} not found at the BaseCamp.";

            if (climber.Stamina == 10)
                return $"{climberName} has no need of recovery.";

            climber.Rest(daysToRecover);

            return $"{climberName} has been recovering for {daysToRecover} days and is ready to attack the mountain.";
        }

        public string NewClimberAtCamp(string name, bool isOxygenUsed)
        {
            IClimber existingClimber = climbers.Get(name);
            if (existingClimber != null)
                return $"{name} is a participant in ClimberRepository and cannot be duplicated.";

            Climber newClimber = isOxygenUsed ? new OxygenClimber(name) : new NaturalClimber(name);
            climbers.Add(newClimber);
            baseCamp.ArriveAtCamp(name);

            return $"{name} has arrived at the BaseCamp and will wait for the best conditions.";
        }

        public string OverallStatistics()
        {
            var climbersList = climbers.All.OrderByDescending(c => c.ConqueredPeaks.Count).ThenBy(c => c.Name).ToList();
            var overallStats = "";

            foreach (var climber in climbersList)
            {
                overallStats += $"***Highway-To-Peak***{Environment.NewLine}{climber}{Environment.NewLine}";

                var conqueredPeaks = climber.ConqueredPeaks
                    .Select(peakName => peaks.Get(peakName))
                    .OrderByDescending(peak => peak.Elevation)
                    .Select(peak => peak.ToString())
                    .ToList();

                overallStats += string.Join($"{Environment.NewLine}", conqueredPeaks) + $"{Environment.NewLine}";
            }

            return overallStats;
        }
    }
}
