﻿using HighwayToPeak.Models.Contracts;
using HighwayToPeak.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HighwayToPeak.Repositories
{
    public class ClimberRepository : IRepository<IClimber>
    {
        private List<IClimber> climber;
        public ClimberRepository() 
        {
            climber = new List<IClimber>();
        }
        public IReadOnlyCollection<IClimber> All => climber.AsReadOnly();

        public void Add(IClimber model)
        {
           climber.Add(model);
        }

        public IClimber Get(string name)
        {
            return climber.FirstOrDefault(x => x.Name == name);
        }
    }
}
