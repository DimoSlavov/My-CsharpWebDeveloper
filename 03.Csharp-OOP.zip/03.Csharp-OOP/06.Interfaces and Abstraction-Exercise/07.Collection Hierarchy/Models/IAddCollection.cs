﻿namespace CollectionHierarchy.Models.Interface
{
    public interface IAddCollection<T>
    {
        int Add(T item);
    }
}