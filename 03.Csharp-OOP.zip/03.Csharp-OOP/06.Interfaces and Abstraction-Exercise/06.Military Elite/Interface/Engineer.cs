﻿using MilitaryElite.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilitaryElite.Interface
{
    public class Engineer : SpecialisedSoldier, IEngineer
    {
        public Engineer(int id, string firstName, string lastName, decimal salary, Corps crops, IReadOnlyCollection<IRepair> repairs) : base(id, firstName, lastName, salary, crops)
        {
            Repairs = repairs;
        }

        public IReadOnlyCollection<IRepair> Repairs { get; private set; }

        public override string ToString()
           => $"{base.ToString()}{Environment.NewLine}Repairs:{Environment.NewLine}  {string.Join(Environment.NewLine + "  ", Repairs)}".TrimEnd();
    }
}
