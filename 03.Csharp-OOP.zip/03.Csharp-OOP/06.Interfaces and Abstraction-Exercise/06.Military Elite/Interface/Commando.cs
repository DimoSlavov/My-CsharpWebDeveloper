﻿using MilitaryElite.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilitaryElite.Interface
{
    public class Commando : SpecialisedSoldier, ICommando
    {
        public Commando(int id, string firstName, string lastName, decimal salary, Corps crops, IReadOnlyCollection<IMissions> missions)
            : base(id, firstName, lastName, salary, crops)
        {
            Missions = missions;
        }

        public IReadOnlyCollection<IMissions> Missions { get; private set; }

        public override string ToString()
           => $"{base.ToString()}{Environment.NewLine}Missions:{Environment.NewLine}  {string.Join(Environment.NewLine + "  ", Missions)}".TrimEnd();
    }
}