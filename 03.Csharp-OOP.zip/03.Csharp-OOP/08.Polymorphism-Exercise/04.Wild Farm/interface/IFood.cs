﻿namespace WildFarm.Models.Interface
{
    public interface IFood
    {
        int Quantity { get; }
    }
}