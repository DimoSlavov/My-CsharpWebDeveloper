﻿namespace Vehicles.Core.Interface
{
    public interface IEngine
    {
        void Run();
    }
}
