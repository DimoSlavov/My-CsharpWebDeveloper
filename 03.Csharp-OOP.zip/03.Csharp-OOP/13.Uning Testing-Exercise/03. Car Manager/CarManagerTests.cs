namespace CarManager.Tests
{
    using Newtonsoft.Json.Linq;
    using NUnit.Framework;
    using System;
    using System.Reflection;
    using System.Xml.Serialization;

    [TestFixture]
    public class CarManagerTests
    {
        private string expectMake = "Nisan";
        private string expectModel = "Xtrail";
        private double expectFuelConsumption = 7.5;
        private double expectFuelCapacity = 60;
        private double expectFuelAmount = 0;
        private Car car;

        [SetUp]
        public void SetUp()
        {
            car = new(expectMake, expectModel, expectFuelConsumption, expectFuelCapacity);
        }

        [Test]
        public void TestConstructorIsCorect()
        {
            Assert.AreEqual(expectMake, car.Make);
            Assert.AreEqual(expectModel, car.Model);
            Assert.AreEqual(expectFuelAmount, car.FuelAmount);
            Assert.AreEqual(expectFuelConsumption, car.FuelConsumption);
            Assert.AreEqual(expectFuelCapacity, car.FuelCapacity);
        }

        [TestCase(null)]
        [TestCase("")]
        public void Test_prop_Make_Trow_argument_Exseption(string make)
        {
            ArgumentException exception = Assert.Throws<ArgumentException>(()
                => car = new(make, expectModel, expectFuelConsumption, expectFuelCapacity));

            Assert.AreEqual("Make cannot be null or empty!", exception.Message);
        }
        [TestCase(null)]
        [TestCase("")]
        public void Test_prop_Model_Trow_argument_Exseption(string model)
        {
            ArgumentException exception = Assert.Throws<ArgumentException>(()
               => car = new(expectMake, model, expectFuelConsumption, expectFuelCapacity));

            Assert.AreEqual("Model cannot be null or empty!", exception.Message);
        }
        [TestCase(0)]
        [TestCase(-1)]
        [TestCase(-10)]
        public void Test_prop_FuelConsumation_Trow_argument_Exseption(double consum)
        {
            ArgumentException exception = Assert.Throws<ArgumentException>(()
               => car = new(expectMake, expectModel, consum, expectFuelCapacity));

            Assert.AreEqual("Fuel consumption cannot be zero or negative!", exception.Message);
        }

        [TestCase(-1)]
        [TestCase(-10)]
        public void Test_prop_Fuel_Capacity_Trow_argument_Exseption(double capacity)
        {
            ArgumentException exception = Assert.Throws<ArgumentException>(()
                => car = new(expectMake, expectModel, expectFuelConsumption, capacity));

            Assert.AreEqual("Fuel capacity cannot be zero or negative!", exception.Message);
        }
        [Test]
        public void Test_Car_Refuel_Should_Is_Corectly()
        {
            car.Refuel(30);
            Assert.AreEqual(30, car.FuelAmount);
            car.Refuel(40);
            Assert.AreEqual(60, car.FuelAmount);
            Assert.AreEqual(car.FuelCapacity, car.FuelAmount);
        }
        [TestCase(0)]
        [TestCase(-1)]
        [TestCase(-10)]
        public void Test_Car_Refuel_Method_ThrowException_ValueZeroOrNegative(double value)
        {
            ArgumentException exception = Assert.Throws<ArgumentException>(()
                => car.Refuel(value));
               

            Assert.AreEqual("Fuel amount cannot be zero or negative!", exception.Message);
        }

        [TestCase(800)]
        [TestCase(700)]
        [TestCase(100)]
        public void Test_Car_Drive_MethodRefuel_Method_WorkCorrectly(double distance)
        {
            double FuelConsumption = 7.5;
            double FuelAmount = 60;

            double expectResult = FuelAmount - ((distance / 100) * FuelConsumption);

            car.Refuel(100);
            car.Drive(distance);

            Assert.AreEqual(expectResult, car.FuelAmount);
        }

        [TestCase(801)]
        [TestCase(900)]
        [TestCase(1000)]
        public void Test_Car_Drive_Method_ThrowException_NotEnoughFuel(double distance)
        {

            double expectResult = (distance / 100) * 7.5;

            car.Refuel(100);


            InvalidOperationException exception = Assert.Throws<InvalidOperationException>(()
                => car.Drive(distance));
               

            Assert.AreEqual("You don't have enough fuel to drive!", exception.Message);
        }





    }
}